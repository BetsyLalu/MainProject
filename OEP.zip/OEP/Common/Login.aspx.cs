﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OEP.Classes;
using System.Data;


namespace OEP.Common
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            loginClass lObj = new loginClass();
            lObj.Email = txt_uname.Text;
            lObj.Password = txt_password.Text;
            dtReg = lObj.ExecuteSelectQueries();
            if(dtReg.Rows.Count>0)
            {
                lbl_mes.Text = "Successful Login";
            }
            else
            {
                lbl_mes.Text = "Invalid User";
            }
        }
    }
}