﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;


namespace OEP.Classes
{
    public class RegExam
    {
        
        private string a_name;
        private string a_dob;
        private string a_gender;
        private string a_category;
        private string a_fname;
        private string a_mname;
        private string a_disability;
        private string a_nationality;
        private string a_address;
        private string a_locality;
        private string a_town;
        private string a_pincode;
        private string a_state;
        private string a_dist;
        private string a_phn;
        private string a_email;

        private string a_exam;
        private string a_examcity1;
        private string a_examcity2;
        private string a_examcity3;
        private string a_examcity4;
        private int ano;

        private string institute10;
        private string university10;
        private string cgpa10;
        private string year10;
        private string institute12;
        private string university12;
        private string cgpa12;
        private string year12;
        private string instituteUg;
        private string universityUg;
        private string cgpaUg;
        private string yearUg;
        private string institutePg;
        private string universityPg;
        private string cgpaPg;
        private string yearPg;
        private int login_no;

        private string pht;
        private string sign;

        public string A_name { get => a_name; set => a_name = value; }
        public string A_dob { get => a_dob; set => a_dob = value; }
        public string A_gender { get => a_gender; set => a_gender = value; }
        public string A_category { get => a_category; set => a_category = value; }
        public string A_fname { get => a_fname; set => a_fname = value; }
        public string A_mname { get => a_mname; set => a_mname = value; }
        public string A_disability { get => a_disability; set => a_disability = value; }
        public string A_nationality { get => a_nationality; set => a_nationality = value; }
        public string A_address { get => a_address; set => a_address = value; }
        public string A_locality { get => a_locality; set => a_locality = value; }
        public string A_town { get => a_town; set => a_town = value; }
        public string A_pincode { get => a_pincode; set => a_pincode = value; }
        public string A_state { get => a_state; set => a_state = value; }
        public string A_dist { get => a_dist; set => a_dist = value; }
        public string A_phn { get => a_phn; set => a_phn = value; }
        public string A_email { get => a_email; set => a_email = value; }
        public string A_exam { get => a_exam; set => a_exam = value; }
        public string A_examcity1 { get => a_examcity1; set => a_examcity1 = value; }
        public string A_examcity2 { get => a_examcity2; set => a_examcity2 = value; }
        public string A_examcity3 { get => a_examcity3; set => a_examcity3 = value; }
        public string A_examcity4 { get => a_examcity4; set => a_examcity4 = value; }
        public int Ano { get => ano; set => ano = value; }
        public string Institute10 { get => institute10; set => institute10 = value; }
        public string University10 { get => university10; set => university10 = value; }
        public string Cgpa10 { get => cgpa10; set => cgpa10 = value; }
        public string Year10 { get => year10; set => year10 = value; }
        public string Institute12 { get => institute12; set => institute12 = value; }
        public string University12 { get => university12; set => university12 = value; }
        public string Cgpa12 { get => cgpa12; set => cgpa12 = value; }
        public string Year12 { get => year12; set => year12 = value; }
        public string InstituteUg { get => instituteUg; set => instituteUg = value; }
        public string UniversityUg { get => universityUg; set => universityUg = value; }
        public string CgpaUg { get => cgpaUg; set => cgpaUg = value; }
        public string YearUg { get => yearUg; set => yearUg = value; }
        public string InstitutePg { get => institutePg; set => institutePg = value; }
        public string UniversityPg { get => universityPg; set => universityPg = value; }
        public string CgpaPg { get => cgpaPg; set => cgpaPg = value; }
        public string YearPg { get => yearPg; set => yearPg = value; }
        public int Login_no { get => login_no; set => login_no = value; }
        public string Pht { get => pht; set => pht = value; }
        public string Sign { get => sign; set => sign = value; }

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;

        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
          

        public void InsertPersonal()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(A_id) from tbl_ExamPersonalDet  ", con);
            //int ano;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
               ano = (int)cMax;
                ano++;
            }
            else
            {
                ano= 1;
            }
            string qry = "insert into tbl_ExamPersonalDet values ('" + ano + "',@aname,@adob,@agen,@acat,@afname,@amnane,@adis,@anat,@aadd,@aloc,@atown,@apin,@astate,@adist,@aphn,@aemail,'" + login_no + "');";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@aname", a_name);
            cmd.Parameters.AddWithValue("@adob", a_dob);
            cmd.Parameters.AddWithValue("@agen", a_gender);
            cmd.Parameters.AddWithValue("@acat", a_category);
            cmd.Parameters.AddWithValue("@afname", a_fname);
            cmd.Parameters.AddWithValue("@amnane", a_mname);
            cmd.Parameters.AddWithValue("@adis", a_disability);
            cmd.Parameters.AddWithValue("@anat", a_nationality);
            cmd.Parameters.AddWithValue("@aadd", a_address);
            cmd.Parameters.AddWithValue("@aloc", a_locality);
            cmd.Parameters.AddWithValue("@atown", a_town);
            cmd.Parameters.AddWithValue("@apin", a_pincode);
            cmd.Parameters.AddWithValue("@astate", a_state);
            cmd.Parameters.AddWithValue("@adist", a_dist);
            cmd.Parameters.AddWithValue("@aphn", a_phn);
            cmd.Parameters.AddWithValue("@aemail", a_email);
            cmd.ExecuteNonQuery();
        }


        public void InsertExam()
        {
            OpenConection();
            SqlCommand command1 = new SqlCommand("Select max(Eid) from tbl_ExamReg  ", con);
            int examno;
            object cMax1 = command1.ExecuteScalar();
            if (cMax1 != DBNull.Value)
            {
                examno = (int)cMax1;
                examno++;
            }
            else
            {
                examno = 1;
            }
            string qry = "insert into tbl_ExamReg values ('" + examno + "',@ename,@city1,@city2,@city3,@city4,'" + ano + "');";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@ename", a_exam);
            cmd.Parameters.AddWithValue("@city1", a_examcity1);
            cmd.Parameters.AddWithValue("@city2", a_examcity2);
            cmd.Parameters.AddWithValue("@city3", a_examcity3);
            cmd.Parameters.AddWithValue("@city4", a_examcity4);
            cmd.ExecuteNonQuery();

        }

        public void InsertAcademics()
        {
            OpenConection();
            SqlCommand command2 = new SqlCommand("Select max(AcademicId) from tbl_ExamAcademics  ", con);
            int acno;
            object cMax2 = command2.ExecuteScalar();
            if (cMax2 != DBNull.Value)
            {
                acno = (int)cMax2;
                acno++;
            }
            else
            {
                acno = 1;
            }
            string qry = "insert into tbl_ExamAcademics values ('" + acno + "',@inst10,@university10,@cgpa10,@year10,@inst12,@university12,@cgpa12,@year12,@instUg,@universityUg,@cgpaUg,@yearUg,@instPg,@universityPg,@cgpaPg,@yearPg,'" + ano + "');";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@inst10", institute10);
            cmd.Parameters.AddWithValue("@university10", university10);
            cmd.Parameters.AddWithValue("@cgpa10", cgpa10);
            cmd.Parameters.AddWithValue("@year10", year10);
            cmd.Parameters.AddWithValue("@inst12", institute12);
            cmd.Parameters.AddWithValue("@university12", university12);
            cmd.Parameters.AddWithValue("@cgpa12", cgpa12);
            cmd.Parameters.AddWithValue("@year12", year12);
            cmd.Parameters.AddWithValue("@instUg", instituteUg);
            cmd.Parameters.AddWithValue("@universityUg", universityUg);
            cmd.Parameters.AddWithValue("@cgpaUg", cgpaUg);
            cmd.Parameters.AddWithValue("@yearUg", yearUg);
            cmd.Parameters.AddWithValue("@instPg", institutePg);
            cmd.Parameters.AddWithValue("@universityPg", universityPg);
            cmd.Parameters.AddWithValue("@cgpaPg", cgpaPg);
            cmd.Parameters.AddWithValue("@yearPg", yearPg);
            cmd.ExecuteNonQuery();
        }


        public void InsertLogin()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(lid) from tbl_Login  ", con);
            //int login_no;
            string utype;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                login_no = (int)cMax;
                login_no++;
            }
            else
            {
                login_no = 1;
            }
            utype = "student";
            string qry = "insert into tbl_Login values ('" + login_no + "',@uname,@password,'" + utype + "');";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@uname", a_email);
            cmd.Parameters.AddWithValue("@password", a_phn);
            cmd.ExecuteNonQuery();
        }


        public void InsertImages()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(Image_id) from tbl_ExamPhotos  ", con);
            int ino;
            object cMax2 = command.ExecuteScalar();
            if (cMax2 != DBNull.Value)
            {
                ino = (int)cMax2;
                ino++;
            }
            else
            {
                ino = 1;
            }
            string qry = "insert into tbl_ExamPhotos values ('" + ino + "',@photo,@sign,'" + ano + "');";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@photo", pht);
            cmd.Parameters.AddWithValue("@sign", sign);
            cmd.ExecuteNonQuery();
        }
    }
}