﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace OEP.Classes
{
    
    public class ViewClass
    {
        private int loginid;
        private int tpcid;
        private string temail;
        private string tphn;

        public int Tpcid { get => tpcid; set => tpcid = value; }
        public int Loginid { get => loginid; set => loginid = value; }
        public string Temail { get => temail; set => temail = value; }
        public string Tphn { get => tphn; set => tphn = value; }

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;

       

        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        public DataTable ExecuteSelectQueries()
        {
            OpenConection();
            DataTable dtReg = new DataTable();
            string a = "Pending";
            SqlCommand command = new SqlCommand("Select * from tbl_tpcReg where tpc_status='" + a + "' ", con);

            SqlDataAdapter da = new SqlDataAdapter(command);// this will query your database and return the result to your datatable
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }


    

        public DataTable Display()
        {
            DataTable dtReg = new DataTable();
            OpenConection();
            SqlCommand command = new SqlCommand(" select * from tbl_tpcReg where tpc_id=@tpcid", con);
            command.Parameters.AddWithValue("@tpcid",tpcid );
            command.ExecuteNonQuery();
            CloseConnection();
            SqlDataAdapter da = new SqlDataAdapter(command);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }


        public void updatedata()
        {
            
            OpenConection();
            string x = "Accepted";
            SqlCommand command = new SqlCommand("update tbl_tpcReg set tpc_status=@status where tpc_id=@tpcid", con);
            command.Parameters.AddWithValue("@tpcid", tpcid);
            command.Parameters.AddWithValue("@status", x);
            command.ExecuteNonQuery();
        }



        public void InsertLogin()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(lid) from tbl_Login  ", con);
            //int login_no;
            string utype;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                loginid = (int)cMax;
                loginid++;
            }
            else
            {
                loginid = 1;
            }
            utype = "tpc";
            string qry = "insert into tbl_Login values ('" + loginid + "',@uname,@password,'" + utype + "');";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@uname", Temail);
            cmd.Parameters.AddWithValue("@password", Tphn);
            cmd.ExecuteNonQuery();
        }

        public void update_lid()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("update tbl_tpcReg set lid='" + loginid + "' where tpc_id=@tpcid", con);
            command.Parameters.AddWithValue("@tpcid", tpcid);
            command.ExecuteNonQuery();
        }

    }
    
}