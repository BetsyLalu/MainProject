﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace OEP.Classes
{
    public class TpcClass
    {
        private string ttype;
        private string tname;
        private string tphn;
        private string temail;
        private string tloc;
        private string tstate;
        private string tdist;
        private string tcity;
        private string tpin;
        private string hname;
        private string hemail;
        private string hphn;
        private string hours;
        private string days;
        private string nodalname;
        private string nodalemail;
        private string nodalphn;
        private string labs;
        private string internet;
        private string computers;
        private string lan;
        //private int login_no;

        public string Ttype { get => ttype; set => ttype = value; }
        public string Tname { get => tname; set => tname = value; }
        public string Tphn { get => tphn; set => tphn = value; }
        public string Temail { get => temail; set => temail = value; }
        public string Tloc { get => tloc; set => tloc = value; }
        public string Tstate { get => tstate; set => tstate = value; }
        public string Tdist { get => tdist; set => tdist = value; }
        public string Tcity { get => tcity; set => tcity = value; }
        public string Tpin { get => tpin; set => tpin = value; }
        public string Hname { get => hname; set => hname = value; }
        public string Hemail { get => hemail; set => hemail = value; }
        public string Hphn { get => hphn; set => hphn = value; }
        public string Hours { get => hours; set => hours = value; }
        public string Days { get => days; set => days = value; }
        public string Nodalname { get => nodalname; set => nodalname = value; }
        public string Nodalemail { get => nodalemail; set => nodalemail = value; }
        public string Nodalphn { get => nodalphn; set => nodalphn = value; }
        public string Labs { get => labs; set => labs = value; }
        public string Internet { get => internet; set => internet = value; }
        public string Computers { get => computers; set => computers = value; }
        public string Lan { get => lan; set => lan = value; }
        //public int Login_no { get => login_no; set => login_no = value; }

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;

        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        public void InsertTpc()
        {
            OpenConection();
            SqlCommand command2 = new SqlCommand("Select max(tpc_id) from tbl_tpcReg  ", con);
            int tno;
            string st;
            st = "Pending";
            int login_no = 0;
            object cMax2 = command2.ExecuteScalar();
            if (cMax2 != DBNull.Value)
            {
                tno = (int)cMax2;
                tno++;
            }
            else
            {
                tno = 1;
            }
            string qry = "insert into tbl_tpcReg values ('" + tno + "',@ttype,@tname,@tphn,@temail,@tloc,@tstate,@tdist,@tcity,@tpin,@hname,@hemail,@hphn,@hours,@days,@nname,@nemail,@nphn,@labs,@internet,@computers,@lan,'" + st + "','" + login_no + "');";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@ttype", ttype);
            cmd.Parameters.AddWithValue("@tname", tname);
            cmd.Parameters.AddWithValue("@tphn", tphn);
            cmd.Parameters.AddWithValue("@temail", temail);
            cmd.Parameters.AddWithValue("@tloc", tloc);
            cmd.Parameters.AddWithValue("@tstate", tstate);
            cmd.Parameters.AddWithValue("@tdist", tdist);
            cmd.Parameters.AddWithValue("@tcity", tcity);
            cmd.Parameters.AddWithValue("@tpin", tpin);
            cmd.Parameters.AddWithValue("@hname", hname);
            cmd.Parameters.AddWithValue("@hemail", hemail);
            cmd.Parameters.AddWithValue("@hphn", hphn);
            cmd.Parameters.AddWithValue("@hours", hours);
            cmd.Parameters.AddWithValue("@days", days);
            cmd.Parameters.AddWithValue("@nname", nodalname);
            cmd.Parameters.AddWithValue("@nemail", nodalemail);
            cmd.Parameters.AddWithValue("@nphn", nodalphn);
            cmd.Parameters.AddWithValue("@labs", labs);
            cmd.Parameters.AddWithValue("@internet", internet);
            cmd.Parameters.AddWithValue("@computers", computers);
            cmd.Parameters.AddWithValue("@lan", lan);
            //cmd.Parameters.AddWithValue("@status", status);
            cmd.ExecuteNonQuery();
        }

        /*public void InsertLogin()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(lid) from tbl_Login  ", con);
            //int login_no;
            string utype;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                Login_no = (int)cMax;
                Login_no++;
            }
            else
            {
                Login_no = 1;
            }
            utype = "tpc";
            string qry = "insert into tbl_Login values ('" + Login_no + "',@uname,@password,'" + utype + "');";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@uname", temail);
            cmd.Parameters.AddWithValue("@password", tphn);
            cmd.ExecuteNonQuery();
        }*/

    }
}