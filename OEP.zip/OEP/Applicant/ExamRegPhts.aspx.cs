﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using OEP.Classes;
using System.Data;

namespace OEP.Applicant
{
    public partial class ExamRegPhts : System.Web.UI.Page
    {
        protected void Button1_Click(object sender, EventArgs e)
        {
            string filename = Path.GetFileName(fu_photo.PostedFile.FileName);
            string ext = Path.GetExtension(filename);
            if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
            {
                string src = Server.MapPath("~/Photos") + "/" + filename;
                fu_photo.PostedFile.SaveAs(src);
                fu_photo.PostedFile.SaveAs(src);
                string picpath = "~/Photos/" + filename;
                img_photo.Visible = true;
                img_sign.Visible = true;
                img_photo.ImageUrl = picpath;
                img_sign.ImageUrl = picpath;
                Session["photopath"] = picpath;
            }
            else
            {
                Response.Write("Please Select An Image File....");
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_save_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            RegExam rObj = new RegExam();
            
            rObj.InsertImages();
        }
    }
}