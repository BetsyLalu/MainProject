﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OEP.Classes;
using System.Data;

namespace OEP.Applicant
{
    public partial class ExamReg : System.Web.UI.Page
    {
        protected void btn_save_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            RegExam rObj = new RegExam();
            rObj.A_name = txt_name.Text;
            rObj.A_dob = txt_dob.Text;
            if (rb_male.Checked)
            {
                rObj.A_gender = rb_male.Text;
            }
            else
            {
                rObj.A_gender = rb_female.Text;
            }
            rObj.A_category = dd_category.SelectedItem.Text;
            rObj.A_fname = txt_fname.Text;
            rObj.A_mname = txt_mname.Text;
            rObj.A_disability = dd_disability.SelectedItem.Text;
            rObj.A_nationality = dd_nationality.SelectedItem.Text;
            rObj.A_address = txt_adress.Text;
            rObj.A_locality = txt_locality.Text;
            rObj.A_town = txt_town.Text;
            rObj.A_pincode = txt_pincode.Text;
            rObj.A_state = dd_state.SelectedItem.Text;
            rObj.A_dist = dd_dist.SelectedItem.Text;
            rObj.A_phn = txt_phn.Text;
            rObj.A_email = txt_email.Text;
            
            rObj.A_exam = dd_exam.SelectedItem.Text;
            rObj.A_examcity1 = dd_examcity1.SelectedItem.Text;
            rObj.A_examcity2 = dd_examcity2.SelectedItem.Text;
            rObj.A_examcity3 = dd_examcity3.SelectedItem.Text;
            rObj.A_examcity4 = dd_examcity4.SelectedItem.Text;

            rObj.Institute10 = txt_institute10.Text;
            rObj.University10 = txt_university10.Text;
            rObj.Cgpa10 = txt_cgpa10.Text;
            rObj.Year10 = txt_year10.Text;
            rObj.Institute12 = txt_institute12.Text;
            rObj.University12 = txt_university12.Text;
            rObj.Cgpa12 = txt_cgpa12.Text;
            rObj.Year12 = txt_year12.Text;
            rObj.InstituteUg = txt_instituteUg.Text;
            rObj.UniversityUg = txt_universityUg.Text;
            rObj.CgpaUg = txt_cgpaUg.Text;
            rObj.YearUg = txt_yearUg.Text;
            rObj.InstitutePg = txt_institutePg.Text;
            rObj.UniversityPg = txt_universityUg.Text;
            rObj.CgpaPg = txt_cgpaPg.Text;
            rObj.YearPg = txt_yearPg.Text;

            rObj.InsertLogin();
            rObj.InsertPersonal();
            rObj.InsertExam();
            rObj.InsertAcademics();
            Response.Redirect("ExamRegPhts.aspx");
            
        }
    }
}