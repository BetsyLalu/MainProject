﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OEP.Classes;
using System.Data;

namespace OEP.TPC
{
    public partial class tpcReg : System.Web.UI.Page
    {

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            TpcClass tObj = new TpcClass();
            tObj.Ttype = dd_instituteType.SelectedItem.Text;
            tObj.Tname = txt_instname.Text;
            tObj.Tphn = txt_instPhn.Text;
            tObj.Temail = txt_instEmail.Text;
            tObj.Tloc = txt_locality.Text;
            tObj.Tstate = dd_instState.SelectedItem.Text;
            tObj.Tdist = dd_instDist.SelectedItem.Text;
            tObj.Tcity = txt_city.Text;
            tObj.Tpin = txt_pin.Text;
            tObj.Hname = txt_headname.Text;
            tObj.Hemail = txt_heademail.Text;
            tObj.Hphn = txt_headphn.Text;
            tObj.Hours = txt_hours.Text;
            tObj.Days = txt_days.Text;
            tObj.Nodalname = txt_nodalname.Text;
            tObj.Nodalemail = txt_nodalemail.Text;
            tObj.Nodalphn = txt_nodalphn.Text;
            tObj.Labs = txt_labs.Text;
            tObj.Internet = txt_internet.Text;
            tObj.Computers = txt_computers.Text;
            tObj.Lan = txt_lan.Text;
            //tObj.InsertLogin();
            tObj.InsertTpc();
        }

    }
}