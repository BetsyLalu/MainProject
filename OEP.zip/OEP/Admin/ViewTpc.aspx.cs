﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OEP.Classes;
using System.Data;

namespace OEP.Admin
{
    public partial class ViewTpc : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            ViewClass sObj = new ViewClass();
            dtReg = sObj.ExecuteSelectQueries();
            if (dtReg.Rows.Count > 0)
            {
                gv_tpc.DataSource = dtReg;
                gv_tpc.DataBind();
            }
        }



        protected void gv_tpc_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "view")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = gv_tpc.Rows[rowIndex];
                Session["tcp_id"] = ((HiddenField)gv_tpc.Rows[rowIndex].FindControl("hdnId")).Value;
                Response.Redirect("TPCFull.aspx");

            }

            else if (e.CommandName == "accept")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = gv_tpc.Rows[rowIndex];
                Session["tcp_id"] = ((HiddenField)gv_tpc.Rows[rowIndex].FindControl("hdnId")).Value;
                ViewClass vc = new ViewClass();
                vc.Tpcid = Convert.ToInt32(Session["tcp_id"]);
                vc.updatedata();
                LoadData();
            }
        
    }

        protected void gv_tpc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}