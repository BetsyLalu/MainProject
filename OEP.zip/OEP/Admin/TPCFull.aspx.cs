﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OEP.Classes;
using System.Data;
using System.Data.SqlClient;

namespace OEP.Admin
{
    public partial class TPCFull : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            load();
        }

       public void load()
        {
            DataTable dtReg = new DataTable();
            ViewClass obj = new ViewClass();
            obj.Tpcid = Convert.ToInt32(Session["tcp_id"]);
            dtReg = obj.Display();
            if (dtReg.Rows.Count > 0)
            {
                txt_iname.Text = Convert.ToString(dtReg.Rows[0]["tpc_name"]);
                txt_itype.Text = Convert.ToString(dtReg.Rows[0]["tpc_type"]);
                txt_iphn.Text= Convert.ToString(dtReg.Rows[0]["tpc_phn"]);
                txt_iemail.Text = Convert.ToString(dtReg.Rows[0]["tpc_email"]);
                txt_locality.Text= Convert.ToString(dtReg.Rows[0]["tpc_locality"]);
                txt_state.Text = Convert.ToString(dtReg.Rows[0]["tpc_state"]);
                txt_district.Text = Convert.ToString(dtReg.Rows[0]["tpc_dist"]);
                txt_city.Text = Convert.ToString(dtReg.Rows[0]["tpc_city"]);
                txt_pincode.Text = Convert.ToString(dtReg.Rows[0]["tpc_pin"]);

                txt_headname.Text = Convert.ToString(dtReg.Rows[0]["tpc_headname"]);
                txt_heademail.Text = Convert.ToString(dtReg.Rows[0]["tpc_heademail"]);
                txt_headphn.Text = Convert.ToString(dtReg.Rows[0]["tpc_headphn"]);
                txt_hours.Text = Convert.ToString(dtReg.Rows[0]["tpc_hours"]);
                txt_days.Text = Convert.ToString(dtReg.Rows[0]["tpc_days"]);

                txt_nodalname.Text = Convert.ToString(dtReg.Rows[0]["tpc_nodalname"]);
                txt_nodalemail.Text = Convert.ToString(dtReg.Rows[0]["tpc_nodalemail"]);
                txt_nodalphn.Text = Convert.ToString(dtReg.Rows[0]["tpc_nodalphn"]);

                txt_labs.Text = Convert.ToString(dtReg.Rows[0]["tpc_labs"]);
                txt_desktops.Text = Convert.ToString(dtReg.Rows[0]["tpc_computers"]);
                txt_internet.Text = Convert.ToString(dtReg.Rows[0]["tpc_internet"]);
                txt_lan.Text = Convert.ToString(dtReg.Rows[0]["tpc_lan"]);

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            ViewClass obj = new ViewClass();
            obj.Tpcid = Convert.ToInt32(Session["tcp_id"]);
            obj.Temail = txt_iemail.Text;
            obj.Tphn = txt_iphn.Text;
            obj.updatedata();
            obj.InsertLogin();
            obj.update_lid();
        }

        
    }
        
    
}